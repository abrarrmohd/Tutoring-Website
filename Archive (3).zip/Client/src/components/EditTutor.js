import React from 'react'

export default function EditTutor() {
  return (
    <div>EditTutor</div>
  )
}
